library(testthat)
library(datarobot)

test_check("datarobot")
